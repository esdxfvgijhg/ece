
/*<?php session_start() ?>*/

function connexion()
{
	window.open("connexion.php");
	/*if($_SESSION["login"]=="")
	{
		<?php header('Location: connexion.php'); ?>
	}
	else
		{

		}*/
} 