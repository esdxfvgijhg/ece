<?php 
	session_start();

	$N=$_SESSION("login");



	?>