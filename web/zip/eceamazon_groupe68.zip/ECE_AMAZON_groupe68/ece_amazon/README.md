# ece_amazon

Pour importer la base de donn�es il faut cr�er une base de donn�es sur 
phpmyadmin du nom de "eceamazon" puis lancer le fichier traitement.phpet rafraichir la page 
au moins 2 fois (pour �tre s�r).
Il devrait y avoir 7 tables.